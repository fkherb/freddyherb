package edu.ncsu.csc411.ps01.simulation;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import edu.ncsu.csc411.ps01.agent.Robot;
import edu.ncsu.csc411.ps01.environment.Environment;
import edu.ncsu.csc411.ps01.environment.Position;
import edu.ncsu.csc411.ps01.environment.Tile;
import edu.ncsu.csc411.ps01.environment.TileStatus;
import edu.ncsu.csc411.ps01.utils.ColorPalette;
import edu.ncsu.csc411.ps01.utils.ConfigurationLoader;
import edu.ncsu.csc411.ps01.utils.MapManager;

/**
 * A Visual Guide toward testing whether your robot agent is operating
 * correctly. This visualization will run for 200 time steps, afterwards it will
 * output the number of tiles cleaned, and a percentage of the room cleaned. DO
 * NOT MODIFY.
 *
 * @author Adam Gaweda
 */
public class VisualizeSimulation extends JFrame {
    private static final long      serialVersionUID = 1L;
    private final EnvironmentPanel envPanel;
    private final Environment      env;
    private final String           mapFile          = "maps/public/map03.txt";
    private final String           configFile       = "config/configNormal.txt";

    /**
     * Builds the environment; while not necessary for this problem set, this
     * could be modified to allow for different types of environments, for
     * example loading from a file, or creating multiple agents that can
     * communicate/interact with each other. The map variable allows you to
     * customize the environment to any configuration. Each line in the list
     * represents a row in the environment, and each character in a string
     * represents a column. The Environment constructor that accepts a String
     * list will review each character and set that tile's status to one of the
     * following mappings. 'D': TileStatus.DIRTY 'C': TileStatus.CLEAN 'W':
     * TileStatus.IMPASSABLE
     */
    public VisualizeSimulation () {
        // Loads configurations from the config directory. If the configNormal
        // file is too large
        // for your monitor's resolution, you can set configFile to
        // configSmall.txt,
        // or configLarge.txt if you want to increase the screen size.

        // ORIGINAL:
        // final Properties properties = ConfigurationLoader.loadConfiguration(
        // configFile );

        // UPDATED: Avoid hiding the field with a local; use the field directly.
        final Properties properties = ConfigurationLoader.loadConfiguration( this.configFile );

        final int iterations = Integer.parseInt( properties.getProperty( "ITERATIONS", "200" ) );
        final int tilesize = Integer.parseInt( properties.getProperty( "TILESIZE", "50" ) );
        final int delay = Integer.parseInt( properties.getProperty( "DELAY", "200" ) );
        final boolean debug = Boolean.parseBoolean( properties.getProperty( "DEBUG", "true" ) );

        // Currently loads the first public test case, but you can change the
        // map file or make your own!

        // ORIGINAL:
        // final String[] map = MapManager.loadMap( mapFile );

        // UPDATED: Use the field directly (consistent with change above).
        final String[] map = MapManager.loadMap( this.mapFile );

        this.env = new Environment( map );

        // ORIGINAL:
        // envPanel = new EnvironmentPanel( this.env, iterations, tilesize,
        // delay, debug );
        // add( envPanel );

        // UPDATED: Insert a control bar (map picker, run button, colors,
        // status),
        // then add the environment panel below it. Simulation logic remains
        // unchanged.
        setLayout( new java.awt.BorderLayout() );
        this.envPanel = new EnvironmentPanel( this.env, iterations, tilesize, delay, debug );
        final SimControlBar controls = new SimControlBar( this.envPanel, this.mapFile );
        add( controls, java.awt.BorderLayout.NORTH );
        add( this.envPanel, java.awt.BorderLayout.CENTER );
    }

    /** Runs the visualization for the simulation. */
    public static void main ( final String[] args ) {
        final JFrame frame = new VisualizeSimulation();

        frame.setTitle( "CSC 411 - Problem Set 01" );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible( true );
        frame.setResizable( false );
    }
}

@SuppressWarnings ( "serial" )
class EnvironmentPanel extends JPanel {
    // ORIGINAL:
    // private final Timer timer;

    // UPDATED: We recreate the timer when starting or reloading, so it cannot
    // be final.
    /** Timer that advances the simulation; recreated for fresh runs. */
    private Timer                timer;

    private Environment          env;
    private ArrayList<Robot>     robots;
    private static int           ITERATIONS;
    public static int            TILESIZE;
    public static int            DELAY;                              // milliseconds
    public static boolean        DEBUG;

    // ORIGINAL palette usage was inline constants in paintComponent.
    // UPDATED: store mutable colors so the toolbar can change them at runtime.

    /** Current color for CLEAN tiles. Initially the original SILVER. */
    private java.awt.Color       colorClean    = ColorPalette.SILVER;
    /** Current color for DIRTY tiles. Initially the original BROWN. */
    private java.awt.Color       colorDirty    = ColorPalette.BROWN;
    /** Current color for IMPASSABLE tiles. Initially the original BLACK. */
    private java.awt.Color       colorWall     = ColorPalette.BLACK;

    /** Fallback robot color if the robot image is not available. */
    private final java.awt.Color colorRobot    = ColorPalette.GREEN;

    /** Optional robot sprite (loaded from assets/robot.png). */
    private BufferedImage        robotIcon     = null;

    /** Steps elapsed in the current run (exposed to the status panel). */
    private int                  timeStepCount = 0;

    // Designs a GUI Panel based on the dimensions of the Environment and
    // implements
    // a Timer object to run the simulation. This timer will iterate through
    // time-steps
    // with a X ms delay (or wait X ms before updating again).
    public EnvironmentPanel ( final Environment env, final int iterations, final int tilesize, final int delay,
            final boolean debug ) {
        ITERATIONS = iterations;
        TILESIZE = tilesize;
        DELAY = delay;
        DEBUG = debug;

        setPreferredSize( new Dimension( env.getCols() * TILESIZE, env.getRows() * TILESIZE ) );
        this.env = env;
        this.robots = env.getRobots();

        // UPDATED: Try to load a fixed robot image from assets/robot.png.
        // If it fails (missing file, etc.), we fallback to drawing a circle.
        try {
            robotIcon = ImageIO.read( new File( "assets/robot.png" ) );
        }
        catch ( final Exception ex ) {
            robotIcon = null;
            if ( DEBUG ) {
                System.out.println( "Robot icon not found, using circle. " + ex.getMessage() );
            }
        }

        // ORIGINAL (inline timer construction and immediate start) was:
        // this.timer = new Timer( DELAY, new ActionListener() { ... });
        // this.timer.start();

        // UPDATED: build the timer via a helper so we can fully reset
        // counters/timer
        // on "Start" and when switching maps. Start paused; the toolbar
        // controls it.
        this.timer = makeTimer();
        this.timer.stop();
    }

    /**
     * Build a brand-new timer with a fresh step counter and stopping behavior.
     * The timer updates the environment, repaints, increments time, and stops
     * on either completion or the iteration limit.
     *
     * @return a configured, paused Timer.
     */
    private Timer makeTimer () {
        timeStepCount = 0; // reset steps for a new run
        return new Timer( DELAY, new ActionListener() {
            @Override
            public void actionPerformed ( final ActionEvent e ) {
                try {
                    // Wrapped in try/catch in case the Robot's decision results
                    // in a crash;
                    // we'll treat that the same as Action.DO_NOTHING.
                    env.updateEnvironment();
                }
                catch ( final Exception ex ) {
                    if ( DEBUG ) {
                        final String error = "[ERROR AGENT CRASH AT TIME STEP %03d] %s\n";
                        System.out.printf( error, timeStepCount, ex );
                    }
                }

                repaint();
                timeStepCount++;

                // Stop the simulation if either of the following conditions
                // occur:
                // 1) The Environment has no more dirty tiles
                // 2) The simulation has iterated through the passed number of
                // iterations
                if ( env.getNumCleanedTiles() == env.getNumTiles() || timeStepCount == ITERATIONS ) {
                    timer.stop();
                    env.printPerformanceMeasure();
                }
            }
        } );
    }

    /**
     * Stop any running timer and create a fresh timer with counters reset. Used
     * by start() and when loading a new map.
     */
    private void resetTimer () {
        if ( timer != null ) {
            timer.stop();
        }
        timer = makeTimer();
    }

    /**
     * Load a new map file and refresh the panel (keeps timer stopped). Called
     * by the control bar when the user selects a different map.
     *
     * @param mapFile
     *            full path to a map text file
     */
    public void loadMap ( final String mapFile ) {
        final String[] map = edu.ncsu.csc411.ps01.utils.MapManager.loadMap( mapFile );
        this.env = new edu.ncsu.csc411.ps01.environment.Environment( map );
        this.robots = env.getRobots();
        setPreferredSize( new Dimension( env.getCols() * TILESIZE, env.getRows() * TILESIZE ) );
        resetTimer(); // important: fresh counter for new map
        revalidate();
        repaint();
    }

    /** Begin a fresh run from the current map state (resets counters). */
    public void start () {
        resetTimer();
        timer.start();
    }

    /** Resume a paused run. */
    public void resume () {
        if ( !timer.isRunning() ) {
            timer.start();
        }
    }

    /** Pause the simulation. */
    public void stop () {
        timer.stop();
    }

    // -------- Stats exposed for the Status panel --------

    /**
     * Current number of CLEAN tiles.
     *
     * @return count of clean tiles
     */
    public int getCleanedTiles () {
        return env.getNumCleanedTiles();
    }

    /**
     * Total number of non-wall tiles in the current map.
     *
     * @return total traversable tiles
     */
    public int getTotalTiles () {
        return env.getNumTiles();
    }

    /**
     * Steps elapsed in the current run.
     *
     * @return time step count
     */
    public int getTimeStepCount () {
        return timeStepCount;
    }

    // -------- Color API used by SimControlBar --------

    /**
     * Returns the color currently used to render CLEAN tiles.
     *
     * @return current CLEAN tile color
     */
    public java.awt.Color getColorClean () {
        return colorClean;
    }

    /**
     * Returns the color currently used to render DIRTY tiles.
     *
     * @return current DIRTY tile color
     */
    public java.awt.Color getColorDirty () {
        return colorDirty;
    }

    /**
     * Returns the color currently used to render IMPASSABLE tiles.
     *
     * @return current wall tile color
     */
    public java.awt.Color getColorWall () {
        return colorWall;
    }

    /**
     * Sets the color used to render CLEAN tiles and repaints the panel.
     *
     * @param c
     *            new CLEAN tile color
     */
    public void setColorClean ( final java.awt.Color c ) {
        this.colorClean = ( c != null ) ? c : this.colorClean;
        repaint();
    }

    /**
     * Sets the color used to render DIRTY tiles and repaints the panel.
     *
     * @param c
     *            new DIRTY tile color
     */
    public void setColorDirty ( final java.awt.Color c ) {
        this.colorDirty = ( c != null ) ? c : this.colorDirty;
        repaint();
    }

    /**
     * Sets the color used to render IMPASSABLE tiles and repaints the panel.
     *
     * @param c
     *            new wall tile color
     */
    public void setColorWall ( final java.awt.Color c ) {
        this.colorWall = ( c != null ) ? c : this.colorWall;
        repaint();
    }

    /*
     * The paintComponent method draws all of the objects onto the panel. This
     * is updated at each time step when we call repaint().
     */
    @Override
    protected void paintComponent ( final Graphics g ) {
        super.paintComponent( g );

        // UPDATED: Center the map within the panel (original drew from 0,0).
        final int mapW = env.getCols() * TILESIZE;
        final int mapH = env.getRows() * TILESIZE;
        final int x0 = Math.max( 0, ( getWidth() - mapW ) / 2 );
        final int y0 = Math.max( 0, ( getHeight() - mapH ) / 2 );

        // Paint Environment Tiles (centered using x0,y0)
        final Map<Position, Tile> tiles = env.getTiles();
        for ( final Position p : tiles.keySet() ) {

            // ORIGINAL constant-based coloring:
            // if ( tiles.get( p ).getStatus() == TileStatus.CLEAN ) {
            // g.setColor( ColorPalette.SILVER );
            // } else if ( tiles.get( p ).getStatus() == TileStatus.DIRTY ) {
            // g.setColor( ColorPalette.BROWN );
            // } else if ( tiles.get( p ).getStatus() == TileStatus.IMPASSABLE )
            // {
            // g.setColor( ColorPalette.BLACK );
            // }

            // UPDATED: use mutable fields so SimControlBar color pickers work.
            if ( tiles.get( p ).getStatus() == TileStatus.CLEAN ) {
                g.setColor( colorClean );
            }
            else if ( tiles.get( p ).getStatus() == TileStatus.DIRTY ) {
                g.setColor( colorDirty );
            }
            else if ( tiles.get( p ).getStatus() == TileStatus.IMPASSABLE ) {
                g.setColor( colorWall );
            }

            // ORIGINAL un-centered draw:
            // g.fillRect( p.getCol() * TILESIZE, p.getRow() * TILESIZE,
            // TILESIZE, TILESIZE );
            // g.setColor( ColorPalette.BLACK );
            // g.drawRect( p.getCol() * TILESIZE, p.getRow() * TILESIZE,
            // TILESIZE, TILESIZE );

            // UPDATED: apply centering offsets when drawing the tiles/grid.
            final int x = x0 + p.getCol() * TILESIZE;
            final int y = y0 + p.getRow() * TILESIZE;
            g.fillRect( x, y, TILESIZE, TILESIZE );
            g.setColor( ColorPalette.BLACK );
            g.drawRect( x, y, TILESIZE, TILESIZE );
        }

        // Paint Robot
        // ORIGINAL: always draw a green circle (no centering offsets).
        // g.setColor( ColorPalette.GREEN );
        // for ( final Robot robot : robots ) {
        // final Position robotPos = env.getRobotPosition( robot );
        // g.fillOval( robotPos.getCol() * TILESIZE + ( TILESIZE / 4 ),
        // robotPos.getRow() * TILESIZE + ( TILESIZE / 4 ),
        // TILESIZE / 2, TILESIZE / 2 );
        // }

        // UPDATED: draw a small robot image if assets/robot.png is available;
        // otherwise fall back to the original green circle. Also apply
        // centering offsets.
        for ( final Robot robot : robots ) {
            final Position pos = env.getRobotPosition( robot );
            final int x = x0 + pos.getCol() * TILESIZE;
            final int y = y0 + pos.getRow() * TILESIZE;
            final int pad = TILESIZE / 8;
            final int w = TILESIZE - 2 * pad;
            final int h = TILESIZE - 2 * pad;

            if ( robotIcon != null ) {
                final Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint( RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR );
                g2.drawImage( robotIcon, x + pad, y + pad, w, h, null );
                g2.dispose();
            }
            else {
                g.setColor( colorRobot );
                g.fillOval( x + ( TILESIZE / 4 ), y + ( TILESIZE / 4 ), TILESIZE / 2, TILESIZE / 2 );
            }
        }
    }
}
