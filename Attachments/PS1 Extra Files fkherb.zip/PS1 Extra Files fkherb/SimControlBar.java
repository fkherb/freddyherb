package edu.ncsu.csc411.ps01.simulation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.File;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import edu.ncsu.csc411.ps01.utils.ColorPalette;

/**
 * Compact toolbar that controls and reports on the simulation.
 *
 * Responsibilities: - Map selection that auto-loads and pauses the simulation -
 * Single run control button: Start, Stop, Resume - Reset Map button that
 * reloads the current map and pauses - Tile color customization for Clean,
 * Dirty, and Wall with Reset - Status panel showing Cleaned, Total, Steps, and
 * Pass/Failed
 *
 * The robot's appearance is fixed by the application code. When
 * assets/robot.png is available, it is used. Otherwise, a green circle is
 * drawn. The user cannot change the robot image or color from this UI.
 */
@SuppressWarnings ( "serial" )
public class SimControlBar extends JPanel {

    /** Available maps: display name to full normalized path. */
    private final LinkedHashMap<String, String> maps     = new LinkedHashMap<>();
    /** Map selector combobox. */
    private final JComboBox<String>             mapCombo = new JComboBox<>();
    /** Full path of the currently selected map. */
    private String                              currentMap;
    /** Target environment panel that this toolbar controls. */
    private final EnvironmentPanel              panel;

    /**
     * Run-state for the single control button. IDLE: ready to start RUNNING:
     * timer is advancing PAUSED: timer is stopped, can resume
     */
    private enum RunState {
        IDLE, RUNNING, PAUSED
    }

    /** Current run-state reflected in the run button. */
    private RunState         state          = RunState.IDLE;

    /**
     * Single run control button that toggles between Start, Stop, and Resume.
     */
    private final JButton    runBtn         = new JButton( "▶ Start" );
    /** Reload current map and stay paused. */
    private final JButton    resetMapBtn    = new JButton( "⟲ Reset Map" );

    /** Label showing the number of cleaned tiles. */
    private final JLabel     cleanedLbl     = new JLabel( "0" );
    /** Label showing the total count of non-wall tiles. */
    private final JLabel     totalLbl       = new JLabel( "0" );
    /** Label showing the number of steps elapsed in the current run. */
    private final JLabel     stepsLbl       = new JLabel( "0" );
    /** Result label showing Pass! or Failed. */
    private final JLabel     resultLbl      = new JLabel( "—" );

    /**
     * UI refresh timer that: - updates stats periodically - evaluates pass/fail
     * at 70% cleaned - detects natural end of a run when the step count stops
     * increasing
     */
    private final Timer      uiRefreshTimer = new Timer( 150, e -> refreshStatus() );

    /** Whether the pass threshold has been achieved during the current run. */
    private boolean          passAchieved   = false;
    /** Last step count seen from the environment panel. */
    private int              lastStepSeen   = -1;
    /** Counts consecutive refresh ticks with no step change while running. */
    private int              stagnantTicks  = 0;
    /**
     * Number of ticks without progress considered sufficient to mark
     * completion.
     */
    private static final int FINISH_TICKS   = 3;

    /**
     * Constructs the control bar for a simulation.
     *
     * @param panel
     *            environment panel that this toolbar will control
     * @param initialMapFile
     *            full path of the map initially loaded
     */
    public SimControlBar ( final EnvironmentPanel panel, final String initialMapFile ) {
        super();
        this.panel = panel;

        setLayout( new BoxLayout( this, BoxLayout.X_AXIS ) );
        setBorder( new EmptyBorder( 6, 8, 6, 8 ) );
        setBackground( new Color( 245, 246, 248 ) );

        final JPanel mapPanel = buildMapPanel( initialMapFile );
        final JPanel runPanel = buildRunPanel();
        final JPanel colorPanel = buildColorPanel();
        final JPanel statusPane = buildStatusPanel();

        add( mapPanel );
        add( hSep() );
        add( runPanel );
        add( hSep() );
        add( colorPanel );
        add( hSep() );
        add( statusPane );
        add( Box.createHorizontalGlue() );

        applyState( RunState.IDLE );

        uiRefreshTimer.start();
        refreshStatus();
    }

    /**
     * Builds the "Map" section: a label + combo box. Ensures the initial
     * selection matches the map actually loaded by VisualizeSimulation by
     * computing the same display key format used in scanMaps(): "subfolder:
     * filename" (or "(root): filename" for files directly under maps/).
     *
     * @param initialMapFile
     *            full path of the initially selected map
     * @return panel containing the map chooser
     */
    private JPanel buildMapPanel ( final String initialMapFile ) {
        scanMaps();

        final JPanel p = new JPanel( new FlowLayout( FlowLayout.LEFT, 8, 4 ) );
        p.setOpaque( false );
        p.setBorder( new TitledBorder( "Map" ) );

        p.add( new JLabel( "Choose:" ) );
        for ( final String name : maps.keySet() ) {
            mapCombo.addItem( name );
        }

        // Compute the exact display key used by scanMaps(): "dirLabel:
        // fileName"
        // Example: maps/public/map03.txt -> "public: map03.txt"
        final String norm = initialMapFile.replace( '\\', '/' );
        String rel = norm;
        final String prefix = "maps/";
        final int at = rel.indexOf( prefix );
        if ( at >= 0 ) {
            rel = rel.substring( at + prefix.length() );
        }
        final int slash = rel.lastIndexOf( '/' );
        final String dirLabel = ( slash >= 0 ) ? rel.substring( 0, slash ) : "(root)";
        final String fileName = ( slash >= 0 ) ? rel.substring( slash + 1 ) : rel;
        final String initialDisplayKey = dirLabel + ": " + fileName;

        if ( maps.containsKey( initialDisplayKey ) ) {
            mapCombo.setSelectedItem( initialDisplayKey );
            currentMap = maps.get( initialDisplayKey );
        }
        else if ( !maps.isEmpty() ) {
            // Fallback: pick the first discovered map and use that consistently
            mapCombo.setSelectedIndex( 0 );
            currentMap = maps.get( mapCombo.getItemAt( 0 ) );
        }
        else {
            // Final fallback: no maps found; preserve whatever was passed in
            currentMap = initialMapFile;
        }

        mapCombo.setToolTipText( "Switch maps (auto-loads into the view and pauses)." );
        mapCombo.addActionListener( e -> {
            final String name = (String) mapCombo.getSelectedItem();
            if ( name == null ) {
                return;
            }

            currentMap = maps.get( name );
            panel.stop();
            panel.loadMap( currentMap ); // load and remain paused
            applyState( RunState.IDLE ); // show Start
            resetResult();
            refreshStatus();
        } );

        p.add( mapCombo );
        return p;
    }

    /**
     * Builds the run controls panel consisting of the single run button and the
     * Reset Map button. The panel is sized so both buttons always remain
     * visible, preventing FlowLayout from wrapping the second button onto a
     * clipped row.
     *
     * @return panel with run controls
     */
    private JPanel buildRunPanel () {
        final JPanel p = new JPanel( new FlowLayout( FlowLayout.LEFT, 8, 4 ) );
        p.setOpaque( false );
        p.setBorder( new TitledBorder( "Run" ) );

        final Dimension btnSize = new Dimension( 120, 28 );
        runBtn.setPreferredSize( btnSize );
        resetMapBtn.setPreferredSize( btnSize );

        runBtn.setToolTipText( "Start / Stop / Resume the simulation." );
        resetMapBtn.setToolTipText( "Reload the current map and pause." );

        runBtn.addActionListener( e -> {
            switch ( state ) {
                case IDLE:
                    resetResult();
                    panel.start();
                    applyState( RunState.RUNNING );
                    break;
                case RUNNING:
                    panel.stop();
                    applyState( RunState.PAUSED );
                    break;
                case PAUSED:
                    panel.resume();
                    applyState( RunState.RUNNING );
                    break;
            }
        } );

        resetMapBtn.addActionListener( e -> {
            panel.stop();
            panel.loadMap( currentMap );
            applyState( RunState.IDLE );
            resetResult();
            refreshStatus();
        } );

        p.add( runBtn );
        p.add( resetMapBtn );

        // >>> Keep both buttons on one row: prevent horizontal squeezing
        final Dimension pref = p.getPreferredSize();
        p.setMinimumSize( pref );
        p.setPreferredSize( pref );
        p.setMaximumSize( new Dimension( pref.width, Integer.MAX_VALUE ) );
        // <<<

        return p;
    }

    /**
     * Builds the color customization panel for tile colors only. The robot
     * appearance is fixed by the application.
     *
     * @return panel with tile color controls
     */
    private JPanel buildColorPanel () {
        final JPanel p = new JPanel( new FlowLayout( FlowLayout.LEFT, 8, 4 ) );
        p.setOpaque( false );
        p.setBorder( new TitledBorder( "Tile Colors" ) );

        final JButton cleanBtn = new JButton( "Clean" );
        final JButton dirtyBtn = new JButton( "Dirty" );
        final JButton wallBtn = new JButton( "Wall" );
        final JButton resetBtn = new JButton( "Reset" );

        cleanBtn.setToolTipText( "Pick color for CLEAN tiles." );
        dirtyBtn.setToolTipText( "Pick color for DIRTY tiles." );
        wallBtn.setToolTipText( "Pick color for IMPASSABLE tiles." );
        resetBtn.setToolTipText( "Restore default palette." );

        cleanBtn.addActionListener( e -> {
            final Color c = JColorChooser.showDialog( this, "Choose Clean Tile Color", panel.getColorClean() );
            if ( c != null ) {
                panel.setColorClean( c );
            }
        } );
        dirtyBtn.addActionListener( e -> {
            final Color c = JColorChooser.showDialog( this, "Choose Dirty Tile Color", panel.getColorDirty() );
            if ( c != null ) {
                panel.setColorDirty( c );
            }
        } );
        wallBtn.addActionListener( e -> {
            final Color c = JColorChooser.showDialog( this, "Choose Wall Color", panel.getColorWall() );
            if ( c != null ) {
                panel.setColorWall( c );
            }
        } );
        resetBtn.addActionListener( e -> {
            panel.setColorClean( ColorPalette.SILVER );
            panel.setColorDirty( ColorPalette.BROWN );
            panel.setColorWall( ColorPalette.BLACK );
        } );

        p.add( cleanBtn );
        p.add( dirtyBtn );
        p.add( wallBtn );
        p.add( new JSeparator( SwingConstants.VERTICAL ) {
            {
                setPreferredSize( new Dimension( 8, 24 ) );
            }
        } );
        p.add( resetBtn );
        return p;
    }

    /**
     * Builds the status panel that displays cleaned tiles, total tiles, steps
     * elapsed, and the pass or failed result.
     *
     * @return panel with status labels
     */
    private JPanel buildStatusPanel () {
        final JPanel p = new JPanel( new FlowLayout( FlowLayout.LEFT, 8, 4 ) );
        p.setOpaque( false );
        p.setBorder( new TitledBorder( "Status" ) );

        final JLabel cleanedTitle = new JLabel( "Cleaned:" );
        final JLabel ofTitle = new JLabel( "/" );
        final JLabel stepsTitle = new JLabel( "  Steps:" );
        final JLabel resultTitle = new JLabel( "  Result:" );

        resultLbl.setForeground( new Color( 80, 80, 80 ) );

        p.add( cleanedTitle );
        p.add( cleanedLbl );
        p.add( ofTitle );
        p.add( totalLbl );
        p.add( stepsTitle );
        p.add( stepsLbl );
        p.add( resultTitle );
        p.add( resultLbl );
        return p;
    }

    /**
     * Applies a new run-state and updates the run button text and tooltip.
     *
     * @param newState
     *            the run-state to apply
     */
    private void applyState ( final RunState newState ) {
        state = newState;
        switch ( state ) {
            case IDLE:
                runBtn.setText( "▶ Start" );
                runBtn.setToolTipText( "Begin a run from the current map state." );
                break;
            case RUNNING:
                runBtn.setText( "⏸ Stop" );
                runBtn.setToolTipText( "Pause the simulation." );
                break;
            case PAUSED:
                runBtn.setText( "⏵ Resume" );
                runBtn.setToolTipText( "Continue the paused run." );
                break;
        }
    }

    /**
     * Creates a slim vertical separator used between sections of the toolbar.
     *
     * @return a vertical separator component
     */
    private JSeparator hSep () {
        final JSeparator s = new JSeparator( SwingConstants.VERTICAL );
        s.setMaximumSize( new Dimension( 10, 36 ) );
        return s;
    }

    /**
     * Recursively scans the maps directory for text files and populates the
     * internal map of display names to full paths.
     *
     * Display format in the UI: "subfolder-path: filename" Examples:
     * maps/public/map01.txt -> "public: map01.txt"
     * maps/private/hard/map07.txt-> "private/hard: map07.txt" maps/map00.txt ->
     * "(root): map00.txt"
     */
    private void scanMaps () {
        maps.clear();

        final File base = new File( "maps" );
        final ArrayDeque<File> st = new ArrayDeque<>();
        if ( base.exists() && base.isDirectory() ) {
            st.push( base );
        }

        // Collect: dirLabel, fileName, fullPath
        final java.util.List<java.util.AbstractMap.SimpleEntry<String, String[]>> found = new java.util.ArrayList<>();
        while ( !st.isEmpty() ) {
            final File d = st.pop();
            final File[] kids = d.listFiles();
            if ( kids == null ) {
                continue;
            }

            for ( final File f : kids ) {
                if ( f.isDirectory() ) {
                    st.push( f );
                }
                else if ( f.getName().toLowerCase().endsWith( ".txt" ) ) {
                    final String full = f.getPath().replace( '\\', '/' );

                    // Relative path under "maps/"
                    String rel = full;
                    final String prefix = "maps/";
                    final int at = rel.indexOf( prefix );
                    if ( at >= 0 ) {
                        rel = rel.substring( at + prefix.length() );
                    }

                    // dirLabel = everything before last '/', "(root)" if none
                    final int slash = rel.lastIndexOf( '/' );
                    final String dirLabel = ( slash >= 0 ) ? rel.substring( 0, slash ) : "(root)";
                    final String fileName = ( slash >= 0 ) ? rel.substring( slash + 1 ) : rel;

                    found.add( new java.util.AbstractMap.SimpleEntry<>( full, new String[] { dirLabel, fileName } ) );
                }
            }
        }

        // Extract numeric part from names like "mapNN.txt"
        final java.util.function.ToIntFunction<String> mapIndex = name -> {
            final java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile( "map(\\d+)", java.util.regex.Pattern.CASE_INSENSITIVE ).matcher( name );
            if ( m.find() ) {
                try {
                    return Integer.parseInt( m.group( 1 ) );
                }
                catch ( final NumberFormatException ignore ) {
                    /* fall through */ }
            }
            // If no number, sort after numbered maps
            return Integer.MAX_VALUE;
        };

        // Sort by: subfolder (case-insensitive), then map number, then filename
        found.sort( ( a, b ) -> {
            final String aDir = a.getValue()[0];
            final String bDir = b.getValue()[0];
            final int dirCmp = aDir.compareToIgnoreCase( bDir );
            if ( dirCmp != 0 ) {
                return dirCmp;
            }

            final String aName = a.getValue()[1];
            final String bName = b.getValue()[1];

            final int ai = mapIndex.applyAsInt( aName );
            final int bi = mapIndex.applyAsInt( bName );
            if ( ai != bi ) {
                return Integer.compare( ai, bi );
            }

            return aName.compareToIgnoreCase( bName );
        } );

        // Fill LinkedHashMap in sorted order with "Subfolder: map##.txt" labels
        for ( final var e : found ) {
            final String dirLabel = e.getValue()[0];
            final String fileName = e.getValue()[1];
            final String display = dirLabel + ": " + fileName;
            maps.put( display, e.getKey() );
        }
    }

    /**
     * Returns a compact display name for a path, using only the file name.
     *
     * @param path
     *            a full or relative path
     * @return the filename portion suitable for display
     */
    private String displayName ( final String path ) {
        final String norm = path.replace( '\\', '/' );
        final int idx = norm.lastIndexOf( '/' );
        return ( idx >= 0 ) ? norm.substring( idx + 1 ) : norm;
    }

    /**
     * Updates Cleaned, Total, and Steps labels from the environment panel,
     * evaluates pass or fail, and heuristically detects the natural end of a
     * run. The pass threshold is 70 percent of non-wall tiles cleaned.
     */
    private void refreshStatus () {
        final int cleaned = panel.getCleanedTiles();
        final int total = panel.getTotalTiles();
        final int steps = panel.getTimeStepCount();

        cleanedLbl.setText( Integer.toString( cleaned ) );
        totalLbl.setText( Integer.toString( total ) );
        stepsLbl.setText( Integer.toString( steps ) );

        if ( total > 0 && ( cleaned * 1.0 / total ) >= 0.70 ) {
            showPass();
        }

        if ( state == RunState.RUNNING ) {
            if ( steps == lastStepSeen ) {
                stagnantTicks++;
                if ( stagnantTicks >= FINISH_TICKS ) {
                    if ( !passAchieved ) {
                        showFail();
                    }
                    applyState( RunState.PAUSED );
                }
            }
            else {
                stagnantTicks = 0;
            }
        }
        else {
            stagnantTicks = 0;
        }

        lastStepSeen = steps;
    }

    /**
     * Resets the result display and internal tracking flags. Used when the map
     * changes, when the map is reset, and at the start of a fresh run.
     */
    private void resetResult () {
        passAchieved = false;
        stagnantTicks = 0;
        lastStepSeen = -1;
        resultLbl.setText( "—" );
        resultLbl.setForeground( new Color( 80, 80, 80 ) );
    }

    /**
     * Displays Pass! in green and records that the threshold has been met.
     */
    private void showPass () {
        if ( !passAchieved ) {
            passAchieved = true;
            resultLbl.setText( "Pass!" );
            resultLbl.setForeground( new Color( 20, 140, 20 ) );
        }
    }

    /**
     * Displays Failed in red.
     */
    private void showFail () {
        resultLbl.setText( "Failed" );
        resultLbl.setForeground( new Color( 170, 40, 40 ) );
    }
}
