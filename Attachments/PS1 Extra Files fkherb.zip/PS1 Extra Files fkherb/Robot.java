package edu.ncsu.csc411.ps01.agent;

import java.util.Map;

import edu.ncsu.csc411.ps01.environment.Action;
import edu.ncsu.csc411.ps01.environment.Environment;
import edu.ncsu.csc411.ps01.environment.Position;
import edu.ncsu.csc411.ps01.environment.Tile;
import edu.ncsu.csc411.ps01.environment.TileStatus;

/**
 * Represents a simple-reflex agent cleaning a particular room. The robot only
 * has one sensor - the ability to retrieve the the status of all its
 * neighboring tiles, including itself.
 */
public class Robot {
    /**
     * Environment of the simulation
     */
    private final Environment env;

    /**
     * Initializes a Robot on a specific tile in the environment.
     *
     * @param env
     *            Environment
     */
    public Robot ( final Environment env ) {
        this.env = env;
    }

    /*
     * Problem Set 01 - Modify the getAction method below in order to simulate
     * the passage of a single time-step. At each time-step, the Robot decides
     * whether to clean the current tile or move tiles. Your task for this
     * Problem Set is to modify the method below such that the Robot agent is
     * able to clean at least 70% of the available tiles on a given Environment.
     * 5 out of the 10 graded test cases, with explanations on how to create new
     * Environments, are available under the test package. This method should
     * return a single Action from the Action class. - Action.CLEAN -
     * Action.DO_NOTHING - Action.MOVE_UP - Action.MOVE_DOWN - Action.MOVE_LEFT
     * - Action.MOVE_RIGHT
     */

    /**
     * Decides one action for this time-step using a small set of reflex rules.
     *
     *
     * Step 1: If the current tile is DIRTY, CLEAN it.
     *
     *
     * Step 2: Otherwise, if any adjacent tile is DIRTY, move onto it (UP, DOWN,
     * LEFT, or RIGHT).
     *
     *
     * Step 3: Otherwise, sweep in a zig-zag pattern: even rows prefer moving
     * RIGHT; odd rows prefer moving LEFT. If the preferred horizontal move is
     * blocked, try moving DOWN to the next row, then try the opposite
     * horizontal, and finally try UP as a last resort.
     *
     *
     * Extras: A dead-end rule leaves one-way pockets immediately, and a
     * bottom-corner escape moves UP when stuck at the bottom edge with the
     * preferred horizontal blocked.
     *
     *
     *
     * @return the Action to take this step
     */
    public Action getAction () {
        /*
         * This example code demonstrates the available methods and actions,
         * such as retrieving its senses (neighbor tiles), getting the status of
         * those tiles, and returning the different available Actions
         * env.getNeighboringTiles(this) will return a Map with key-value pairs
         * for each neighbor, using a String key for a Tile value
         */
        final Map<String, Tile> positions = env.getNeighborTiles( this );
        final Tile self = positions.get( "self" );
        final Tile above = positions.get( "above" ); // Either a Tile object or
                                                     // null
        final Tile below = positions.get( "below" ); // Either a Tile object or
                                                     // null
        final Tile left = positions.get( "left" ); // Either a Tile object or
                                                   // null
        final Tile right = positions.get( "right" ); // Either a Tile object or
                                                     // null

        System.out.println( "self: " + self );
        System.out.println( "above: " + above );
        System.out.println( "left: " + left );
        System.out.println( "below: " + below );
        System.out.println( "right: " + right );

        // 1) Clean here if dirty.
        // Simple reflex: if this tile is DIRTY, clean it now.
        if ( self != null && self.getStatus() == TileStatus.DIRTY ) {
            return Action.CLEAN;
        }

        // Helpers
        // passable: true if the tile exists and is not a wall.
        // isDirty: true if the tile exists and is DIRTY.
        final java.util.function.Function<Tile, Boolean> passable = t -> t != null
                && t.getStatus() != TileStatus.IMPASSABLE;
        final java.util.function.Function<Tile, Boolean> isDirty = t -> t != null && t.getStatus() == TileStatus.DIRTY;

        // 2) Greedy: move onto adjacent dirt immediately.
        // Check each neighbor; if any is DIRTY and passable, step onto it.
        if ( isDirty.apply( above ) && passable.apply( above ) ) {
            return Action.MOVE_UP;
        }
        if ( isDirty.apply( below ) && passable.apply( below ) ) {
            return Action.MOVE_DOWN;
        }
        if ( isDirty.apply( left ) && passable.apply( left ) ) {
            return Action.MOVE_LEFT;
        }
        if ( isDirty.apply( right ) && passable.apply( right ) ) {
            return Action.MOVE_RIGHT;
        }

        // Quick dead-end escape: if exactly one direction is open, take it.
        // This prevents dithering in one-way pockets.
        final boolean canAbove = passable.apply( above );
        final boolean canBelow = passable.apply( below );
        final boolean canLeft = passable.apply( left );
        final boolean canRight = passable.apply( right );
        final int open = ( canAbove ? 1 : 0 ) + ( canBelow ? 1 : 0 ) + ( canLeft ? 1 : 0 ) + ( canRight ? 1 : 0 );
        if ( open == 1 ) {
            if ( canAbove ) {
                return Action.MOVE_UP;
            }
            if ( canBelow ) {
                return Action.MOVE_DOWN;
            }
            if ( canLeft ) {
                return Action.MOVE_LEFT;
            }
            if ( canRight ) {
                return Action.MOVE_RIGHT;
            }
        }

        // 3) Sweep with bottom-corner escape.
        // Determine sweep direction from row parity: even rows go RIGHT, odd
        // rows LEFT.
        final Position p = env.getRobotPosition( this );
        final boolean preferRight = ( p.getRow() % 2 == 0 );

        // Bottom-edge corner escape:
        // If we cannot go DOWN (at bottom or blocked) and our preferred
        // horizontal is blocked,
        // go UP to break bottom-row ping-pong loops.
        final boolean atBottom = !canBelow;
        final boolean horizBlocked = preferRight ? !canRight : !canLeft;
        if ( atBottom && horizBlocked && canAbove ) {
            return Action.MOVE_UP;
        }

        // Primary sweep ordering:
        // Try preferred horizontal first; if blocked, try going DOWN to the
        // next row,
        // then try the opposite horizontal, and finally go UP as a last resort.
        if ( preferRight ) {
            if ( canRight ) {
                return Action.MOVE_RIGHT; // keep sweeping right on even rows
            }
            if ( canBelow ) {
                return Action.MOVE_DOWN; // drop to next row
            }
            if ( canLeft ) {
                return Action.MOVE_LEFT; // backtrack horizontally
            }
            if ( canAbove ) {
                return Action.MOVE_UP; // last resort: go up
            }
        }
        else { // prefer left on odd rows
            if ( canLeft ) {
                return Action.MOVE_LEFT; // keep sweeping left on odd rows
            }
            if ( canBelow ) {
                return Action.MOVE_DOWN; // drop to next row
            }
            if ( canRight ) {
                return Action.MOVE_RIGHT; // backtrack horizontally
            }
            if ( canAbove ) {
                return Action.MOVE_UP; // last resort: go up
            }
        }

        // If no movement is possible (surrounded by walls), do nothing this
        // step.
        return Action.DO_NOTHING;
    }

    @Override
    public String toString () {
        return "Robot [neighbors=" + env.getNeighborTiles( this ) + "]";
    }
}
